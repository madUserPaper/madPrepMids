package pk.edu.iqra.firstapp.utils

import android.widget.Button

fun Button.getButtonText(){

}