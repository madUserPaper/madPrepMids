package pk.edu.iqra.firstapp.utils

import java.io.Serializable

data class User(val name:String,val dob:String, val mobileNo:String):Serializable